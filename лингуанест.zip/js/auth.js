/**
 * LinguaNest — Auth Page JavaScript
 * Fully functional registration & login using the LinguaNest data store.
 */

document.addEventListener('DOMContentLoaded', () => {
    const registerCard = document.getElementById('registerCard');
    const loginCard = document.getElementById('loginCard');
    const authSuccess = document.getElementById('authSuccess');
    const showLoginLink = document.getElementById('showLoginLink');
    const showRegisterLink = document.getElementById('showRegisterLink');
    const registerForm = document.getElementById('registerForm');
    const loginForm = document.getElementById('loginForm');
    const regPassword = document.getElementById('regPassword');
    const errorMsg = document.createElement('div');
    errorMsg.className = 'auth-error';
    errorMsg.style.cssText = 'color: #ef4444; font-size: 0.85rem; margin-top: -8px; margin-bottom: 12px; display: none; padding: 8px 12px; background: rgba(239,68,68,0.1); border-radius: 8px;';

    // If already logged in, redirect
    const currentUser = LinguaNest.getCurrentUser();
    if (currentUser) {
        redirectToDashboard(currentUser.role);
        return;
    }

    // ---- Toggle Login / Register ----
    const showLogin = () => {
        registerCard.style.display = 'none';
        loginCard.style.display = 'block';
        loginCard.style.animation = 'fadeInUp 0.4s ease-out';
        hideError();
    };

    const showRegister = () => {
        loginCard.style.display = 'none';
        registerCard.style.display = 'block';
        registerCard.style.animation = 'fadeInUp 0.4s ease-out';
        hideError();
    };

    if (showLoginLink) showLoginLink.addEventListener('click', (e) => { e.preventDefault(); showLogin(); });
    if (showRegisterLink) showRegisterLink.addEventListener('click', (e) => { e.preventDefault(); showRegister(); });

    // Check URL hash
    if (window.location.hash === '#login') {
        showLogin();
    }

    // ---- Password Strength ----
    if (regPassword) {
        regPassword.addEventListener('input', () => {
            const strength = calcStrength(regPassword.value);
            updateBars(strength);
        });
    }

    function calcStrength(pw) {
        let s = 0;
        if (pw.length >= 8) s++;
        if (pw.length >= 12) s++;
        if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
        if (/\d/.test(pw)) s++;
        if (/[^A-Za-z0-9]/.test(pw)) s++;
        return Math.min(s, 4);
    }

    function updateBars(strength) {
        const level = strength <= 1 ? 'weak' : strength <= 2 ? 'medium' : 'strong';
        ['str1', 'str2', 'str3', 'str4'].forEach((id, i) => {
            const bar = document.getElementById(id);
            if (bar) {
                bar.className = 'strength-bar';
                if (i < strength) bar.classList.add('active', level);
            }
        });
    }

    // ---- Error Handling ----
    function showError(form, message) {
        const clone = errorMsg.cloneNode(true);
        // Remove any existing error
        form.querySelectorAll('.auth-error').forEach(e => e.remove());
        clone.textContent = message;
        clone.style.display = 'block';
        form.prepend(clone);
        shakeForm(form);
    }

    function hideError() {
        document.querySelectorAll('.auth-error').forEach(e => e.remove());
    }

    // ---- Register ----
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            hideError();

            const firstName = document.getElementById('firstName').value.trim();
            const lastName = document.getElementById('lastName').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const password = regPassword.value;
            const roleEl = document.querySelector('input[name="role"]:checked');
            const role = roleEl ? roleEl.value : 'student';
            const language = document.getElementById('language').value;

            // Validation
            if (!firstName || !lastName) {
                showError(registerForm, 'Please enter your first and last name.');
                return;
            }
            if (!email || !email.includes('@')) {
                showError(registerForm, 'Please enter a valid email address.');
                return;
            }
            if (password.length < 8) {
                showError(registerForm, 'Password must be at least 8 characters.');
                return;
            }

            // Submit button loading
            const btn = document.getElementById('registerBtn');
            btn.innerHTML = '⏳ Creating Account...';
            btn.disabled = true;

            setTimeout(() => {
                const result = LinguaNest.register({ firstName, lastName, email, password, role, language });

                if (!result.success) {
                    btn.innerHTML = 'Create Account';
                    btn.disabled = false;
                    showError(registerForm, result.error);
                    return;
                }

                // Success!
                registerCard.style.display = 'none';
                if (authSuccess) authSuccess.classList.add('show');

                setTimeout(() => redirectToDashboard(role), 1500);
            }, 800);
        });
    }

    // ---- Login ----
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            hideError();

            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;

            if (!email) {
                showError(loginForm, 'Please enter your email.');
                return;
            }
            if (!password) {
                showError(loginForm, 'Please enter your password.');
                return;
            }

            const btn = document.getElementById('loginBtn');
            btn.innerHTML = '⏳ Logging in...';
            btn.disabled = true;

            setTimeout(() => {
                const result = LinguaNest.login(email, password);

                if (!result.success) {
                    btn.innerHTML = 'Log In';
                    btn.disabled = false;
                    showError(loginForm, result.error);
                    return;
                }

                btn.innerHTML = '✓ Success!';
                setTimeout(() => redirectToDashboard(result.user.role), 600);
            }, 600);
        });
    }

    // ---- Google Sign In (Demo) ----
    document.querySelectorAll('#googleSignUp, #googleSignIn').forEach(btn => {
        btn.addEventListener('click', () => {
            btn.innerHTML = '<span style="animation: spin 1s linear infinite; display: inline-block;">⏳</span> Connecting...';

            setTimeout(() => {
                // Login as Alex Kim (demo volunteer)
                LinguaNest.login('alex@school.edu', 'password123');
                redirectToDashboard('volunteer');
            }, 1200);
        });
    });

    // ---- Role Selection Visual Feedback ----
    document.querySelectorAll('input[name="role"]').forEach(option => {
        option.addEventListener('change', () => {
            const label = option.closest('.role-option')?.querySelector('.role-label');
            if (label) {
                label.style.animation = 'none';
                label.offsetHeight;
                label.style.animation = 'fadeIn 0.3s ease-out';
            }
        });
    });

    // ---- Helpers ----
    function redirectToDashboard(role) {
        if (role === 'admin') window.location.href = 'admin.html';
        else if (role === 'volunteer') window.location.href = 'dashboard-volunteer.html';
        else window.location.href = 'dashboard-student.html';
    }

    function shakeForm(form) {
        form.style.animation = 'none';
        form.offsetHeight;
        form.style.animation = 'shake 0.5s ease-in-out';
    }

    // Inject shake keyframe
    const style = document.createElement('style');
    style.textContent = `
        @keyframes shake { 0%,100%{transform:translateX(0)} 10%,30%,50%,70%,90%{transform:translateX(-4px)} 20%,40%,60%,80%{transform:translateX(4px)} }
        @keyframes fadeInUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
    `;
    document.head.appendChild(style);
});
